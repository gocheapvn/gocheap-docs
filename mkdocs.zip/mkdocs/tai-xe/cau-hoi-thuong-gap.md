# Câu hỏi thường gặp (FAQ) cho Tài xế

**Q1: Tôi có cần ký hợp đồng giấy không?**  
A1: Không, hợp đồng điện tử là đủ.  

**Q2: Khi nào tôi nhận được tiền?**  
A2: Bạn có thể rút tiền từ ví bất cứ lúc nào và nhận tiền vào ngày các 10-20-30 hàng tháng 

**Q3: Nếu khách hủy chuyến thì sao?**  
A3: Tài xế sẽ nhận được hỗ trợ từ hotline để giảm và tránh việc mất chi phí rủi ro.  

**Q4: Nếu tôi gặp sự cố giao thông?**  
A4: Gọi hotline 0934343141/02473000600 để được hỗ trợ ngay.  
