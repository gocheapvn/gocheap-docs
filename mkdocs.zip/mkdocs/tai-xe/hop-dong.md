# Hợp đồng & Quy định hợp tác

## 1. Loại hợp đồng
- Hợp đồng hợp tác dịch vụ (không ràng buộc lao động).  
- Thời hạn hợp đồng: 12 tháng (tự động gia hạn).  

## 2. Quyền lợi đối tác
- Tự do nhận chuyến hoặc từ chối chuyến.  
- Thu nhập minh bạch, hiển thị chi tiết trên app.  
- Được hỗ trợ pháp lý và bảo hiểm chuyến đi.  

## 3. Nghĩa vụ đối tác
- Tuân thủ luật giao thông Việt Nam.  
- Cập nhật hồ sơ đầy đủ, hợp lệ.  
- Giữ gìn hình ảnh và uy tín thương hiệu GOCheap.  

## 4. Chấm dứt hợp đồng
- Hai bên có thể chấm dứt hợp đồng bất cứ lúc nào, thông báo trước 7 ngày.  
- Tài khoản vi phạm nghiêm trọng có thể bị khóa ngay lập tức.  
