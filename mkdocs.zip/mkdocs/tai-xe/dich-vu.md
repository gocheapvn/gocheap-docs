# Dịch vụ & Chính sách dành cho Tài xế

## 1. Dịch vụ cung cấp
- **Lái xe hộ**: lái xe của khách hàng, lái xe máy, ô tô; lái xe cho sếp, lái xe khi say, lái xe dự án... 
- **Xe sân bay**: nhận chuyến đưa đón sân bay.  
- **Xe hợp đồng**: chủ yếu là khách hàng doanh nghiệp.  

## 2. Chính sách hoa hồng
- Mức phí: từ 20-40% tùy dịch vụ.  
- Thưởng doanh thu (đang nghiên cứu).  
- Thưởng chất lượng (điểm đánh giá khách hàng).  

## 3. An toàn & hỗ trợ
- Bảo hiểm chuyến đi cho tài xế và khách hàng.  
- Hỗ trợ khẩn cấp 24/7.  
