# Hướng dẫn sử dụng ứng dụng GOCheap DriverX

## 1. Đăng nhập
- Sử dụng số điện thoại đã đăng ký.  
- Xác thực OTP.  

## 2. Nhận chuyến
- Màn hình hiển thị yêu cầu đặt xe/thuê tài xế.  
- Xem thông tin khách, điểm đón, giá cước, thời gian.  
- Nhấn **Nhận chuyến** để xác nhận.  

## 3. Thực hiện chuyến đi
- Liên hệ khách hàng qua số trung gian: 0968.333.406.  
- Bấm di chuyển
- Đón khách đúng điểm và đúng giờ hẹn.  
- Kích hoạt trạng thái “Bắt đầu chuyến”.  
- Khi kết thúc: Nhấn **Kết thúc chuyến**.  

## 4. Thanh toán
- Khách có thể trả tiền mặt hoặc chuyển khoản công ty.  
- Tài xế xem chi tiết thu nhập tại mục **Ví**.  

## 5. Các tính năng khác
- Bản đồ điều hướng trực tiếp.  
- Hỗ trợ gửi vị trí.  
- Báo cáo sự cố qua OA.  
