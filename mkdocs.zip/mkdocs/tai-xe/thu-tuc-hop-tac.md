# Thủ tục hợp tác dành cho Đối tác Tài xế

## 1. Hồ sơ cần chuẩn bị
- CMND/CCCD còn hiệu lực.  
- Giấy phép lái xe hạng B2 trở lên (cho ô tô), A1/A2 (cho xe máy).  
- Đăng ký xe, đăng kiểm (nếu là dịch vụ xe).  
- Bảo hiểm trách nhiệm dân sự bắt buộc.  
- Giấy khám sức khỏe & LLTP (trong 6 tháng gần nhất).  

## 2. Quy trình đăng ký
1. **Đăng ký online** tại [gocheap.vn/taixe](https://gocheap.vn/taixe).  
2. **Nộp hồ sơ giấy** tại văn phòng GOCheap hoặc gửi bản scan qua email.  
3. **Tham gia buổi đào tạo** online/offline.  
4. **Ký hợp đồng hợp tác điện tử**.  
5. **Kích hoạt tài khoản** sau khi được xét duyệt.  

## 3. Phí & Chính sách
- Không thu phí tham gia nhưng mỗi hạng thành viên có chính sách cọc hoặc không
- Tính phí hoa hồng theo từng chuyến thành công.  
- Tài xế nhận tiền mặt hoặc về ví GOCheap, có thể rút bất kỳ lúc nào và nhận các ngày 10-20-30 hàng tháng

## 4. Hỗ trợ
- Hotline 24/7: 024.7300.1022  
- Email: hotro@gocheap.vn  
