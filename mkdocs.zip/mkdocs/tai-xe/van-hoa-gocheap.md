# Văn hóa công ty GOCheap

- 🤝 **Tôn trọng & hợp tác**: coi tài xế là đối tác bình đẳng.  
- 🚗 **An toàn trên hết**: không nhận chuyến khi mệt mỏi, say rượu.  
- 🌱 **Phát triển bền vững**: gắn bó lâu dài, cùng nhau tăng thu nhập.  
- ⭐ **Dịch vụ xuất sắc**: mỗi tài xế là một “đại sứ thương hiệu”.  
- 😃 **Khách hàng là trung tâm**: luôn lắng nghe, phục vụ tận tâm.  
