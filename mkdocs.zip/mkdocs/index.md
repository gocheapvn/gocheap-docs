# Hướng dẫn sử dụng GOCheap 🚖

Chào mừng bạn đến với **docs.gocheap.vn** – cẩm nang chính thức của GOCheap.  

Tại đây, bạn sẽ tìm thấy:

- 📱 **Khách hàng**: Hướng dẫn cài đặt ứng dụng, thuê tài xế, thanh toán, chính sách dịch vụ.  
- 🚗 **Đối tác Lái xe**: Thủ tục hợp tác, hợp đồng, cách sử dụng ứng dụng, chỉ dẫn dịch vụ, văn hóa công ty.  
- 🤝 **Thông tin hỗ trợ chung**: Liên hệ, bảo mật, điều khoản dịch vụ.  

👉 Hãy chọn danh mục phù hợp để bắt đầu.  
