# Thanh toán trên GOCheap

## 1. Hình thức thanh toán
- Tiền mặt.  
- Chuyển khoản.  
- Thẻ ngân hàng (Visa/Master/JCB).  

## 2. Hoá đơn
- Khách hàng có thể yêu cầu xuất hoá đơn điện tử.  

## 3. Chính sách hủy chuyến
- Hủy trước khi tài xế nhận: miễn phí.  
- Hủy sau khi tài xế nhận: phí hủy (đang nghiên cứu)  
