# Cài đặt & Đăng ký ứng dụng GOCheap

## 1. Tải ứng dụng
- **Android**: Google Play → tìm "GOCheap".  
- **iOS**: App Store → tìm "GOCheap".  

## 2. Đăng ký tài khoản
- Nhập số điện thoại.  
- Nhận mã OTP để xác thực.  
- Điền tên, email (tùy chọn).  

## 3. Cập nhật thông tin chủ xe
- Thêm biển số xe và loại xe.  
