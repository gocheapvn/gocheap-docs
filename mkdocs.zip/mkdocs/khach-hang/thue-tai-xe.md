# Cách đặt dịch vụ trên GOCheap

1. Mở ứng dụng GOCheap.  
2. Nhập **điểm đón** và **điểm đến**.  
3. Chọn loại dịch vụ: Lái xe hộ / Xe sân bay/ Xe doanh nghiệp.  
4. Xác nhận giá hiển thị.  
5. Nhấn **Đặt xe/Thuê tài xế** và chờ tài xế đến.  

💡 Mẹo: Đặt xe sớm hơn 15-30 phút để chủ động thời gian.  
