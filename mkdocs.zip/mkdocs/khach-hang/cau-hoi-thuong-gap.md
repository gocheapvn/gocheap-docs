# Câu hỏi thường gặp (FAQ) cho Khách hàng

**Q1: Tôi có thể đặt dịch vụ khi chưa có internet không?**  
A1: Có bạn có thể gọi hotline 24/24: 024.73000.636.  

**Q2: Nếu tài xế hủy chuyến thì sao?**  
A2: Hệ thống sẽ tự động kết nối tài xế khác gần bạn.  

**Q3: Tôi có thể thanh toán bằng thẻ quốc tế không?**  
A3: Có, GOCheap hỗ trợ Visa/Master/JCB.  

**Q4: Tôi cần hóa đơn VAT?**  
A4: Vào mục “Lịch sử chuyến đi” → chọn chuyến → xuất hóa đơn.  
