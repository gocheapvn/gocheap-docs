# Chính sách bảo mật

- GOCheap cam kết bảo mật thông tin khách hàng và tài xế.  
- Dữ liệu cá nhân chỉ được sử dụng cho mục đích cung cấp dịch vụ.  
- Không chia sẻ thông tin cho bên thứ ba khi chưa có sự đồng ý.  
