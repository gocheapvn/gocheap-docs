# Điều khoản dịch vụ GOCheap

- Khi sử dụng dịch vụ, khách hàng và tài xế đồng ý tuân thủ các điều khoản này.  
- GOCheap có quyền cập nhật điều khoản mà không cần thông báo trước.  
- Mọi tranh chấp sẽ được giải quyết theo pháp luật Việt Nam.  
